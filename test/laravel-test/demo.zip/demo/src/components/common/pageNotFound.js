const PageNotFound = () =>{
    return(
        <section className="bg-light" id="services">
      <div className="container px-4">
        <div className="row gx-4 justify-content-center">
          <div className="col-lg-8">
            <h1>404 Page not found</h1>
          </div>
        </div>
      </div>
    </section>
    )
}

export default PageNotFound