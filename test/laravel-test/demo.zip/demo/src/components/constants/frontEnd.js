export const LOGIN_API_URL='https://6de8-49-34-207-249.ngrok.io/api/login'
export const AUTH_API = 'https://d097-49-34-207-249.ngrok.io/api/me'
export const encrypt_key='iuj8i54k'
export const intervalTime = 3
export const success = "hello welcome you are successfully logged in"
export const linkUsed = "link is already used"
export const linkExpired = "link is expired"