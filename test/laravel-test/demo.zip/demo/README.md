### Installation: yarn

### To run: yarn start

### Change the environment variables to spin up the frontend instance and backend endpoint